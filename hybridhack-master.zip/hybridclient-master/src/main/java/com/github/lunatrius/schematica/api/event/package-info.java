@API(owner = "SchematicaAPI", apiVersion = "1.1", provides = "SchematicaAPI|Events")
package com.github.lunatrius.schematica.api.event;

import net.minecraftforge.fml.common.API;

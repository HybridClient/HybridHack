package me.ionar.salhack.util;

public class SalVec3d
{
    public double x, y, z;
    
    public SalVec3d(double _x, double _y, double _z)
    {
        x = _x;
        y = _y;
        z = _z;
    }
}

package me.ionar.salhack.module;

public interface ValueListeners
{
    public void OnValueChange(final Value p_Val);
}

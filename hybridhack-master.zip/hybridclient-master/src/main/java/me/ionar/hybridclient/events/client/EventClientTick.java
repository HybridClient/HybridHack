package me.ionar.salhack.events.client;

import me.ionar.salhack.events.MinecraftEvent;

public class EventClientTick extends MinecraftEvent
{

}

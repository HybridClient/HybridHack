package me.ionar.salhack.events.entity;

import me.ionar.salhack.events.MinecraftEvent;

public class EventSteerEntity extends MinecraftEvent
{
}

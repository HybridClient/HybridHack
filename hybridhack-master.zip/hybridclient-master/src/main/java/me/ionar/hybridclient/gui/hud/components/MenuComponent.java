package me.ionar.salhack.gui.hud.components;

import me.ionar.salhack.gui.hud.HudComponentItem;

public class MenuComponent extends HudComponentItem
{

    public MenuComponent(String p_DisplayName, float p_X, float p_Y)
    {
        super(p_DisplayName, p_X, p_Y);
    }

}

package me.ionar.salhack.util;

public class RotationSpoof
{
    public float Pitch;
    public float Yaw;
    
    public RotationSpoof(float l_Pos, float l_Pos2)
    {
        Yaw = l_Pos;
        Pitch = l_Pos2;
    }
}

package me.ionar.salhack.events.blocks;

import me.ionar.salhack.events.MinecraftEvent;

public class EventCanCollideCheck extends MinecraftEvent
{

}

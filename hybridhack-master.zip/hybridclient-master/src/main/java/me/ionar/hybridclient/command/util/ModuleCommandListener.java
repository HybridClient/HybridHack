package me.ionar.salhack.command.util;

public interface ModuleCommandListener
{
    public void OnHide();
    public void OnToggle();
    public void OnRename(String p_NewName);
}
